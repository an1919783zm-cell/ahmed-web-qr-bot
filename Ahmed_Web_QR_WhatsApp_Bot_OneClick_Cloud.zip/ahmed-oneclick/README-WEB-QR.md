# Ahmed Web QR WhatsApp Bot

## Local
npm install
npm start
Open http://localhost:3000

## Render
Deploy as a Node web service. The included render.yaml uses a persistent disk at /var/data so WhatsApp auth can survive restarts. If your Render plan does not support persistent disks, use another persistent-volume setup; otherwise the session can be lost after a restart.

Scan: WhatsApp > Linked devices > Link a device.

Never publish the auth folder or its credentials. Anyone with the saved auth can control the linked WhatsApp account.
