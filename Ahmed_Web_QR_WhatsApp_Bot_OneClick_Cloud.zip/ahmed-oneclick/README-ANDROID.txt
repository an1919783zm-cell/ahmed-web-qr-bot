AHMED SIMPLE WHATSAPP BOT - ANDROID

Requirements:
- Android
- Termux
- Internet
- A WhatsApp account you control

INSTALL:
1. Install Termux from a trusted/current source.
2. Open Termux and enter:
   pkg update -y
   pkg install nodejs -y

3. Extract this ZIP, enter the bot folder, then run:
   npm install
   npm start

4. A QR will appear in Termux.
5. In WhatsApp, open:
   Settings > Linked devices > Link a device
   Then scan the QR.

Commands:
 /help
 /ping
 /info

The bot only implements these basic commands. Keep the WhatsApp account under your control and follow WhatsApp's rules.

STOP:
Press Ctrl+C in Termux.

RESET LOGIN:
Stop the bot, delete the "auth" folder, then run npm start again.
