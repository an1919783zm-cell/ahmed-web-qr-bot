const path = require("path");
const express = require("express");
const QRCode = require("qrcode");
const P = require("pino");
const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion
} = require("@whiskeysockets/baileys");

const PORT = Number(process.env.PORT || 3000);
const AUTH_DIR = process.env.AUTH_DIR || path.join(process.cwd(), "auth");
const app = express();
let sock = null;
let status = "starting";
let qrDataUrl = null;
let clients = new Set();
let starting = false;

app.get("/", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.get("/health", (req, res) => res.json({ ok: true, status }));
app.get("/events", (req, res) => {
  res.set({ "Content-Type": "text/event-stream", "Cache-Control": "no-cache", Connection: "keep-alive" });
  res.flushHeaders?.();
  res.write(`data: ${JSON.stringify({ status, qr: qrDataUrl })}\n\n`);
  clients.add(res);
  req.on("close", () => clients.delete(res));
});

function broadcast(payload) {
  const data = `data: ${JSON.stringify(payload)}\n\n`;
  for (const res of clients) res.write(data);
}

async function setQR(qr) {
  qrDataUrl = qr ? await QRCode.toDataURL(qr, { width: 360, margin: 2 }) : null;
  broadcast({ status, qr: qrDataUrl });
}

async function startBot() {
  if (starting) return;
  starting = true;
  status = "connecting";
  broadcast({ status, qr: qrDataUrl });

  try {
    const { state, saveCreds } = await useMultiFileAuthState(AUTH_DIR);
    const { version } = await fetchLatestBaileysVersion();

    sock = makeWASocket({
      version,
      auth: state,
      logger: P({ level: "silent" }),
      printQRInTerminal: false,
      browser: ["Ahmed Web QR Bot", "Chrome", "1.0.0"]
    });

    sock.ev.on("creds.update", saveCreds);

    sock.ev.on("connection.update", async ({ connection, lastDisconnect, qr }) => {
      if (qr) {
        status = "scan_qr";
        await setQR(qr);
        console.log("New WhatsApp QR generated.");
      }

      if (connection === "open") {
        status = "connected";
        qrDataUrl = null;
        broadcast({ status, qr: null });
        console.log("✅ Ahmed Web QR Bot connected!");
        starting = false;
      }

      if (connection === "close") {
        qrDataUrl = null;
        const code = lastDisconnect?.error?.output?.statusCode;
        starting = false;
        if (code === DisconnectReason.loggedOut) {
          status = "logged_out";
          broadcast({ status, qr: null });
          console.log("❌ Logged out. Remove auth storage and scan again.");
        } else {
          status = "reconnecting";
          broadcast({ status, qr: null });
          setTimeout(startBot, 3000);
        }
      }
    });

    sock.ev.on("messages.upsert", async ({ messages }) => {
      const msg = messages[0];
      if (!msg?.message || msg.key.fromMe) return;
      const jid = msg.key.remoteJid;
      const text = msg.message.conversation || msg.message.extendedTextMessage?.text || "";
      const command = text.trim().toLowerCase();

      const replies = {
        "/ping": "🏓 Pong!",
        "/alive": "🟢 Ahmed Web QR Bot is alive!",
        "/info": "🤖 Ahmed Web QR WhatsApp Bot\n⚡ Node.js + Baileys\n🌐 Browser QR enabled",
        "/help": "Use /menu to see the available commands.",
        "/menu": `🤖 Ahmed Web QR Bot\n\n/help /menu /ping /alive /info\n/time /date /uptime\n/jid /id /owner /rules\n/say /echo /reverse /count /upper /lower\n/calc /choose /8ball /coin /dice\n/groupinfo /admins /tagall`,
        "/owner": "👤 Owner: Ahmed",
        "/rules": "📜 Be respectful. No spam or abuse.",
        "/time": `🕐 ${new Date().toLocaleTimeString()}`,
        "/date": `📅 ${new Date().toLocaleDateString()}`,
        "/uptime": `⏱️ ${formatUptime(process.uptime())}`,
        "/jid": `🆔 ${jid}`,
        "/id": `🆔 ${jid}`,
        "/coin": Math.random() < 0.5 ? "🪙 Heads" : "🪙 Tails",
        "/dice": `🎲 ${Math.floor(Math.random() * 6) + 1}`,
        "/8ball": ["🎱 Yes", "🎱 No", "🎱 Maybe", "🎱 Ask again later"][Math.floor(Math.random() * 4)]
      };

      if (replies[command]) return sock.sendMessage(jid, { text: replies[command] });
      if (command.startsWith("/say ") || command.startsWith("/echo ")) return sock.sendMessage(jid, { text: text.trim().slice(text.indexOf(" ") + 1) });
      if (command.startsWith("/reverse ")) return sock.sendMessage(jid, { text: text.trim().slice(9).split("").reverse().join("") });
      if (command.startsWith("/upper ")) return sock.sendMessage(jid, { text: text.trim().slice(7).toUpperCase() });
      if (command.startsWith("/lower ")) return sock.sendMessage(jid, { text: text.trim().slice(7).toLowerCase() });
      if (command.startsWith("/count ")) return sock.sendMessage(jid, { text: `🔢 ${text.trim().slice(7).length} characters` });
      if (command.startsWith("/choose ")) {
        const options = text.trim().slice(8).split("|").map(x => x.trim()).filter(Boolean);
        return sock.sendMessage(jid, { text: options.length ? `🎯 ${options[Math.floor(Math.random() * options.length)]}` : "Use: /choose pizza | burger" });
      }
      if (command.startsWith("/calc ")) {
        const expr = text.trim().slice(6);
        if (!/^[0-9+\-*/().% ]+$/.test(expr)) return sock.sendMessage(jid, { text: "❌ Only basic numbers and + - * / % ( ) are allowed." });
        try { return sock.sendMessage(jid, { text: `🧮 ${Function(`"use strict"; return (${expr})`)()}` }); } catch { return sock.sendMessage(jid, { text: "❌ Invalid calculation." }); }
      }
      if (command === "/groupinfo") {
        try { const m = await sock.groupMetadata(jid); return sock.sendMessage(jid, { text: `👥 ${m.subject}\nMembers: ${m.participants.length}\nOwner: ${m.owner || "N/A"}` }); } catch { return sock.sendMessage(jid, { text: "❌ This command works in groups." }); }
      }
      if (command === "/admins") {
        try { const m = await sock.groupMetadata(jid); const admins = m.participants.filter(p => p.admin).map(p => `@${p.id.split("@")[0]}`); return sock.sendMessage(jid, { text: `👑 Admins:\n${admins.join("\n") || "None"}`, mentions: m.participants.filter(p => p.admin).map(p => p.id) }); } catch { return sock.sendMessage(jid, { text: "❌ Group only." }); }
      }
      if (command === "/tagall") {
        try { const m = await sock.groupMetadata(jid); const mentions = m.participants.map(p => p.id); return sock.sendMessage(jid, { text: mentions.map(x => `@${x.split("@")[0]}`).join(" "), mentions }); } catch { return sock.sendMessage(jid, { text: "❌ Group only." }); }
      }
    });
  } catch (err) {
    console.error(err);
    starting = false;
    status = "error";
    broadcast({ status, qr: null });
    setTimeout(startBot, 5000);
  }
}

function formatUptime(seconds) {
  const d = Math.floor(seconds / 86400); seconds %= 86400;
  const h = Math.floor(seconds / 3600); seconds %= 3600;
  const m = Math.floor(seconds / 60); const s = Math.floor(seconds % 60);
  return `${d}d ${h}h ${m}m ${s}s`;
}

app.listen(PORT, "0.0.0.0", () => {
  console.log(`🌐 Web QR page: http://localhost:${PORT}`);
  startBot();
});
