# Ahmed Web QR WhatsApp Bot

Phone-friendly cloud deployment package for the Ahmed WhatsApp bot.

## One-click Render deployment

This project includes `render.yaml` so Render can create the web service automatically from a Git repository. The persistent disk stores WhatsApp authentication under `/var/data/auth`, so the linked session survives restarts and deploys.

> **Important:** Render persistent disks require a paid web service plan. Without persistent storage, the WhatsApp login can be lost after a restart/redeploy.

### Phone-only setup
1. Upload this folder to a GitHub repository from your Android browser.
2. Open Render and choose **New → Blueprint**.
3. Select the GitHub repository and deploy the Blueprint.
4. Wait for the service to become live.
5. Open the generated `onrender.com` URL.
6. Scan the QR with WhatsApp → **Linked devices** → **Link a device**.

The app has `/health` for the Render health check and uses port `PORT` supplied by Render.

## Commands

Use `/menu` in WhatsApp to see the available commands.
