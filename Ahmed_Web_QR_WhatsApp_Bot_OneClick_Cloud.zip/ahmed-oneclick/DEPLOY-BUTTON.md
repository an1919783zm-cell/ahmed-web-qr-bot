# Render Deploy Button

After this project is uploaded to a public GitHub repository, replace `YOUR_GITHUB_USER/YOUR_REPO` below with that repository and put this in your README:

[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy?repo=https://github.com/YOUR_GITHUB_USER/YOUR_REPO)

Render's Deploy to Render button uses the repository's `render.yaml` Blueprint.
